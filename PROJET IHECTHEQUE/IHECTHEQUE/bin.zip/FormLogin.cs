﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IHECTHEQUE
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }
        //On va faire disparaître le texte dès que l'utilisateur clique
        private void txtEmail_Enter(object sender, EventArgs e)
        {
            if (txtEmail.Text == "Adresse email")
            {
                txtEmail.Text = "";
                txtEmail.ForeColor = Color.Black;
            }
        }
        //On va faire disparaître le texte dès que l'utilisateur clique
        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (txtEmail.Text == "")
            {
                txtEmail.Text = "Adresse email";
                txtEmail.ForeColor = Color.Gray;
            }
        }
        //Pour txtPassword diparait
        private void txtPassword_Enter(object sender, EventArgs e)
        {
            if (txtPassword.Text == "Mot de passe")
            {
                txtPassword.Text = "";
                txtPassword.UseSystemPasswordChar = true;
                txtPassword.ForeColor = Color.Black;
            }
        }
        //Pour txtPassword disparait
        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "")
            {
                txtPassword.UseSystemPasswordChar = false;
                txtPassword.Text = "Mot de passe";
                txtPassword.ForeColor = Color.Gray;
            }
        }

        private void btnLoginConnexion_Click(object sender, EventArgs e)
        {
            if (chkSouvenir.Checked)
            {
                // Enregistrer les infos
                Properties.Settings.Default.Email = txtEmail.Text;
                Properties.Settings.Default.Password = txtPassword.Text;
                Properties.Settings.Default.SeSouvenir = true;
            }
            else
            {
                // Vider les infos
                Properties.Settings.Default.Email = "";
                Properties.Settings.Default.Password = "";
                Properties.Settings.Default.SeSouvenir = false;
            }

            Properties.Settings.Default.Save();

            // ... ici tu ajoutes la vérification vers la BD ou autre
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblCréerCompte_Click(object sender, EventArgs e)
        {
            FormSignup signup = new FormSignup();
            signup.Show();
            this.Hide(); // cache la page login si tu veux
        }

        private void lblOublie_Click(object sender, EventArgs e)
        {
            FormSignup signup = new FormSignup();
            signup.Show();
            this.Hide(); // si tu veux cacher le formulaire actuel
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void pbEye_Click(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !txtPassword.UseSystemPasswordChar;
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            // Chargement des infos si elles existent
            txtEmail.Text = Properties.Settings.Default.Email;
            txtPassword.Text = Properties.Settings.Default.Password;
            chkSouvenir.Checked = Properties.Settings.Default.SeSouvenir;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
 }


